"""Normalise the user supplied public SLDC archive, without filling missing observations.

Input: /mnt/data/sldc_archive.zip, output: this directory. No external requests.
This is a first-pass extraction, not a plant-level dispatch calibration.
"""
import csv
import datetime as dt
import hashlib
import io
import json
from collections import Counter, defaultdict
from pathlib import Path
import zipfile

ARCHIVE = Path('/mnt/data/sldc_archive.zip')
OUT = Path(__file__).resolve().parent
ROOT='sldc_archive/'
STATIONS={
'Idukki','Sabarigiri','Idamalayar','Sholayar','Pallivasal',
'Kuttiadi','Panniar','Neriamangalam','Lower Periyar',
'Poringalkuthu, PLBE','Sengulam','Kakkad','Kallada','Malankara',
'Maniyar','Kuthungal','HYDEL(Contd..) Thottiyar','PES-Pallivasal',
'Thottiyar'
}
RESERVOIRS={
'IDUKKI','PAMBA','KAKKI','SHOLAYAR','IDAMALAYAR','KUNDALA',
'MADUPPATTY','KUTTIADI','THARIODE','ANAYIRANKAL','PONMUDI',
'NERIAMANGALAM','PORINGAL','SENGULAM (SBR)','LOWER PERIYAR','KAKKAD'
}

def val(row,index):
    s=row[index].strip() if index <len(row) else ''
    return s if s else ''

def write(name, headers, records):
    with (OUT/name).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=headers,extrasaction='ignore')
        w.writeheader();w.writerows(records)

with zipfile.ZipFile(ARCHIVE) as z:
    data=list(csv.DictReader(io.StringIO(z.read(ROOT+'index.csv').decode('utf-8-sig'))))
    bykey={(r['date'],r['section']):r for r in data}
    assert len(bykey)==1825, 'Date/section index incomplete or duplicated'
    dates=sorted({r['date'] for r in data})
    def table(date, section):
        path=f'{ROOT}tables/{section}/{date}/table_03.csv'
        return list(csv.reader(io.StringIO(z.read(path).decode('utf-8-sig'))))
    balance=[];stations=[];imports=[];reservoirs=[];extrema=[]
    bad_hash=[];bad_dates=[];balance_bad=[];import_bad=[]
    counts=Counter();missing=[]
    for date in dates:
        sections=[bykey[(date,s)] for s in ('generation','imports','storage','availability','others')]
        if any(x['status']!='ok' for x in sections):
            missing.append(date)
            assert all(x['status']=='missing' for x in sections)
            balance.append({'date':date,'status':'missing','classification':'not_observed'})
            continue
        counts['observed_dates']+=1
        for r in sections:
            source=z.read(ROOT+r['raw_html'])
            if hashlib.sha256(source).hexdigest()!=r['sha256']:
                bad_hash.append((date,r['section']))
            import re
            found=re.search(r'(\d{2}[./]\d{2}[./]\d{4})',source.decode('utf-8','replace'))
            if not found or found.group(1).replace('.','/')!=dt.date.fromisoformat(date).strftime('%d/%m/%Y'):
                bad_dates.append((date,r['section']))
            counts['observed_html']+=1
        g=bykey[(date,'generation')]
        b={'date':date,'status':'observed','classification':'official_observed_reference','source_sha256':g['sha256'],
           'hydro_mu':g['hydel_mu'],'internal_generation_mu':g['internal_generation_mu'],
           'net_import_mu':g['net_import_mu'],'consumption_mu':g['consumption_mu']}
        delta=float(b['internal_generation_mu'])+float(b['net_import_mu'])-float(b['consumption_mu'])
        b['balance_residual_mu']=format(delta,'.10g')
        if abs(delta)>.001:balance_bad.append((date,delta))
        balance.append(b)
        for row in table(date,'generation'):
            name=val(row,0)
            if name in STATIONS:
                stations.append({'date':date,'station_name_as_reported':name,
                    'generation_mu':val(row,1),'month_cumulative_mu':val(row,2),
                    'source_daily_average_mu':val(row,3),
                    'reported_maximum_output_mw':val(row,4),
                    'reported_maximum_output_time':val(row,5),
                    'planned_shutdown_reported':val(row,6),
                    'forced_shutdown_reported':val(row,7),
                    'machines_available_reported':val(row,8),
                    'mp_reported':val(row,9),'ep_reported':val(row,10),
                    'classification':'official_observed_reference',
                    'source_sha256':g['sha256']})
        ir=bykey[(date,'imports')]
        seen_import=False
        selected=[]
        for row in table(date,'imports'):
            name=val(row,0)
            if name.startswith('IMPORT'):
                seen_import=True
                name=name.removeprefix('IMPORT').strip()
            if name=='Net Import':
                break
            if seen_import and name.startswith(('400KV','220KV','110KV')):
                observed=val(row,1)
                imports.append({'date':date,'interface_name_as_reported':name,
                    'import_mu':observed,'month_cumulative_mu':val(row,2),
                    'source_daily_average_mu':val(row,3),
                    'classification':'official_observed_reference','source_sha256':ir['sha256']})
                if observed: selected.append(float(observed))
        # Interfaces may be grouped or non-additive; do not force this gate.
        if abs(sum(selected)-float(b['net_import_mu']))>.1:
            import_bad.append((date,format(sum(selected)-float(b['net_import_mu']),'.8g')))
        sr=bykey[(date,'storage')]
        for row in table(date,'storage'):
            name=val(row,4)
            if name in RESERVOIRS:
                reservoirs.append({'date':date,'reservoir_name_as_reported':name,
                    'min_drawdown_level_m':val(row,0),'full_reservoir_level_m':val(row,1),
                    'full_reservoir_storage_mcm':val(row,2),
                    'full_reservoir_storage_reported_mu':val(row,3),
                    'level_m':val(row,5),'effective_storage_mcm':val(row,6),
                    'storage_percent':val(row,7),
                    'generation_capability_gross_mu':val(row,8),
                    'generation_capability_station_mu':val(row,9),
                    'classification':'official_observed_reference','source_sha256':sr['sha256']})
        other=bykey[(date,'others')]
        context=''
        for row in table(date,'others'):
            label=val(row,0)
            if label in ('Maximum Demand -   '+dt.date.fromisoformat(date).strftime('%d.%m.%Y'), 'Maximum Demand','Minimum Demand'):
                context='maximum' if 'Maximum' in label else 'minimum'
            if label in ('Day','Evening','Morning','Night'):
                period=label
            if val(row,1) in ('Generation','Consumption') and val(row,2):
                extrema.append({'date':date,'category':context,'period':period,
                    'metric':val(row,1),'mw':val(row,2),'time_from':val(row,3),
                    'time_to':val(row,5),'frequency_hz':val(row,7),
                    'classification':'official_observed_reference',
                    'source_sha256':other['sha256']})
    assert not bad_hash, bad_hash[:3]
    assert not bad_dates, bad_dates[:3]
    assert not balance_bad, balance_bad[:3]
    headers={
    'daily_balance.csv':['date','status','classification','hydro_mu','internal_generation_mu','net_import_mu','consumption_mu','balance_residual_mu','source_sha256'],
    'hydro_station_daily.csv':['date','station_name_as_reported','generation_mu','month_cumulative_mu','source_daily_average_mu','reported_maximum_output_mw','reported_maximum_output_time','planned_shutdown_reported','forced_shutdown_reported','machines_available_reported','mp_reported','ep_reported','classification','source_sha256'],
    'import_interface_daily.csv':['date','interface_name_as_reported','import_mu','month_cumulative_mu','source_daily_average_mu','classification','source_sha256'],
    'reservoir_daily.csv':['date','reservoir_name_as_reported','min_drawdown_level_m','full_reservoir_level_m','full_reservoir_storage_mcm','full_reservoir_storage_reported_mu','level_m','effective_storage_mcm','storage_percent','generation_capability_gross_mu','generation_capability_station_mu','classification','source_sha256'],
    'selected_intraday_extrema.csv':['date','category','period','metric','mw','time_from','time_to','frequency_hz','classification','source_sha256']}
    for name,rows in [('daily_balance.csv',balance),('hydro_station_daily.csv',stations),('import_interface_daily.csv',imports),('reservoir_daily.csv',reservoirs),('selected_intraday_extrema.csv',extrema)]:
        write(name,headers[name],rows)
    observed=[r for r in balance if r['status']=='observed']
    report={
      'source_archive_sha256':hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
      'source':'Kerala SLDC public dated form reports; user-acquired raw HTML; index.csv retains retrieval time and per-response SHA256',
      'financial_year':'2024-04-01 to 2025-03-31',
      'expected_days':365,'observed_days':len(observed),
      'missing_dates':missing,
      'sections_per_observed_day':5,'verified_raw_html_count':counts['observed_html'],
      'bad_raw_sha256_count':len(bad_hash),'bad_response_report_date_count':len(bad_dates),
      'max_abs_daily_balance_residual_mu':max(abs(float(r['balance_residual_mu'])) for r in observed),
      'observed_days_totals_mu':{k:round(sum(float(r[k]) for r in observed),4) for k in ('hydro_mu','internal_generation_mu','net_import_mu','consumption_mu')},
      'observed_days_import_interface_additivity_discrepancies_gt_0_1_mu':len(import_bad),
      'sample_import_interface_discrepancies':import_bad[:8],
      'normalized_row_counts':{ 'daily_balance':len(balance),'hydro_station':len(stations),'import_interface':len(imports),'reservoir':len(reservoirs),'selected_intraday_extrema':len(extrema)},
      'limitations':['No hourly/15-minute continuous demand or dispatch time series',
          'Rows for non-reporting dates are explicitly missing, not zero or interpolated',
          'Blank station cells remain blank (not equated to zero)',
          'No reservoir-to-generator physical topology or cascade/double-count protection is established',
          'Daily observed generation maxima are not plant nameplate capacities',
          'Daily interchange energy is not line MW transfer capability',
          'The original downloader has redundant CSV table exports: table_01 includes document context and table_03 contains the principal data table; do not concatenate them',
          'Availability/merit order section has variable table count and rate coverage; not fully normalised here']
    }
    (OUT/'qa_report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    (OUT/'README.md').write_text('''# SLDC FY2024–25 first-pass processed evidence

This package is a **derived extraction of the uploaded sldc_archive.zip**, not new measurements. Keep the original user archive and its raw HTML. The source SHA-256 is recorded in `qa_report.json`; individual response SHA-256 is retained in every row and may be matched to the original `index.csv` and manifest.

Every recorded number is sourced from a dated public SLDC report; no missing dates, empty fields or other values have been inferred, filled or converted to zero. The FY2024–25 totals are sums **only over observed days**. Import-interface sums are descriptive checks, not physical import capacity.

`daily_balance.csv`: one row per FY day, including 11 missing-date markers. Units MU (million kWh), i.e. 1 MU = 1 GWh.

`hydro_station_daily.csv`: names exactly as printed, including the date's reported maximum MW. This is not a commissioned-capacity register. A blank reported generation is unknown, not zero.

`import_interface_daily.csv`: reported import energy by named 400/220/110 kV grouped interface, not individual physical line ratings.

`reservoir_daily.csv`: reported levels, volumes, storage %, and gross/station generation capability. These source headings are retained as separate fields; do **not** sum station capability across reservoirs or impose cascade topology without independent review.

`selected_intraday_extrema.csv`: only published morning/day/evening/night selected extrema, not a complete measured load curve.

`qa_report.json`: date/section coverage, cryptographic integrity, accounting checks and documented limitations. Raw archive has redundant table_01 and table_03 extracts; table_03 is used for normalization, preventing double-counting.

This dataset can feed observational plots and validate a historical **daily energy** representation. A calibrated hourly PyPSA model still requires actual 8,760/35,040 time-block load and interchange observations, independently sourced cost/asset constraints and hydro physical mapping.
''',encoding='utf-8')
print(json.dumps(report,indent=2))
